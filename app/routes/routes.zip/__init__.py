# app/routes/__init__.py

from .register_routes import register_routes

__all__ = ["register_routes"]

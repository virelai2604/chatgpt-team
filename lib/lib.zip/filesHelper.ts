import { fetchWithRetry } from "./httpClient";

export async function handleUpload(request: Request): Promise<Response> {
  const contentType = request.headers.get("Content-Type") || "";
  if (!contentType.includes("multipart/form-data")) {
    return new Response("Invalid Content-Type, expecting multipart/form-data", { status: 400 });
  }

  const headers = buildOpenAIHeaders(request);
  return fetchWithRetry("https://api.openai.com/v1/files", {
    method: "POST",
    headers,
    body: request.body
  });
}

export async function proxyRequest(request: Request, url: string, method = "GET"): Promise<Response> {
  const headers = buildOpenAIHeaders(request);
  const hasBody = method !== "GET" && method !== "HEAD";
  return fetchWithRetry(url, {
    method,
    headers,
    body: hasBody ? request.body : undefined
  });
}

export function buildOpenAIHeaders(request: Request): Headers {
  const headers = new Headers();
  const auth = request.headers.get("Authorization");
  if (auth) headers.set("Authorization", auth);
  const org = request.headers.get("OpenAI-Org");
  if (org) headers.set("OpenAI-Org", org);
  const project = request.headers.get("OpenAI-Project");
  if (project) headers.set("OpenAI-Project", project);
  return headers;
}
